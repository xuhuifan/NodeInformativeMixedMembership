Please load the lightspeed toolbox first. 

Start from Beta_MMSB and mask_Beta_MMSB. 

Beta_MMSB is only for the training purpose while mask_Beta_MMSB includes the link prediction results. 

Note: we use a concept "mask" to denote the unseen links for the prediction task. This is quite inefficient 
and the readers are expected to explore more efficient ways. 

Please cite the below related paper while using this code. 

Xuhui Fan, Richard Yi Da Xu, Longbing Cao, Yin Song. Learning Hidden Structures with Relational Models 
by Adequately Involving Rich Information in A Network. IEEE Transaction on Cybernetics. DOI: 10.1109/TCYB.2016.2521376.

